package ed.example.enviadatos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import Clases.Bebida;
import Clases.Hamburguesa;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

logtextview=(TextView) findViewById(R.id.textView9);
scrollView=(ScrollView) findViewById(R.id.scrollview);


Bundle bundle= this.getIntent().getExtras();
Log("CLIENTE "+bundle.getString("CLIENTE"));
Log(" ");
        Log("HAMBURGUESA :");
        Log("cantidad burger a pedir  :"+bundle.get("NUMHAM"));

        Hamburguesa mihamb = (Hamburguesa) bundle.get("HAMBURGUESA");
        Log(mihamb.getTipo());
        if(mihamb.getCebolla()){Log("con cebolla ");}
        else        {Log("sin cebolla ");}
        Log("**********");
        Log("BEBIDA :");
        Log("cantidad bebidas a pedir  :"+bundle.get("NUMBEB"));
        Bebida mibeb = (Bebida) bundle.get("BEBIDA");
        Log(mibeb.getTipo());
        if(mibeb.getHielo()){Log("con hielo ");}
        else        {Log("sin hielo ");}



    }




    private TextView logtextview;
    private ScrollView scrollView;

    private void Log(String S){

        logtextview.append("\n"+S);
        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }
}