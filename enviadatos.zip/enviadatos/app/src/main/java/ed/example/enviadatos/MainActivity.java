package ed.example.enviadatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Clases.Hamburguesa;
import Clases.Bebida;
public class MainActivity extends AppCompatActivity {


    private EditText numHam;
    private EditText numBeb;
    private EditText cliente;
    private Spinner lista01;
    private Spinner lista02;
    private Spinner lista03;
    private CheckBox hielo;
    private Button enviar;
    private List<String> tipoh;
    private List<String> sino;
    private List<String> tipobebida;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //numero de hamburguesas
        numHam = (EditText) findViewById(R.id.numHam);
        //numero de bebidas
        numBeb = (EditText) findViewById(R.id.numBeb);

        cliente = (EditText) findViewById(R.id.CLIENTE);
        lista01= (Spinner) findViewById(R.id.spinner);
        lista02 = (Spinner) findViewById(R.id.spinner2);
        lista03 = (Spinner) findViewById(R.id.spinner3);
        hielo =(CheckBox) findViewById(R.id.checkBox);
        enviar = (Button) findViewById(R.id.button);
        datosinicio();

    }
  public void   datosinicio(){
        List<String> tipoH =new ArrayList<String>();
        List<String> tipoB =new ArrayList<String>();
        List<String> sino =new ArrayList<String>();
        tipoH.add("carne");
        tipoH.add("pollo");
        tipoH.add("pescado");
      ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,tipoH);
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      lista01.setAdapter(adapter);



      sino.add("SI");sino.add("NO");
      ArrayAdapter<String> adapter2 =new ArrayAdapter<String>
              (this,android.R.layout.simple_spinner_item,sino);
      adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      lista02.setAdapter(adapter2);

  }

    public void noti01(String S)
    {
        String mess=S;
        Toast Toast1=Toast.makeText(getApplicationContext(),mess,Toast.LENGTH_LONG);
        Toast1.show();
    }


public void llamaractividad(View v){

        //evita cantidad invalida
    if(numBeb.getText().length()==0) {numBeb.setText("0");noti01("su pedido sera sin bebidas");}
    if(numHam.getText().length()==0) {numHam.setText("0");noti01("su pedido sera sin hamburguesas");}



        //evita cliente vacio
    if(cliente.getText().length()>3) {
        boolean cebolla = false;
        if (lista02.getSelectedItem().toString().equals("SI")) cebolla = true;
        Hamburguesa miham = new Hamburguesa(lista01.getSelectedItem().toString(), cebolla);


        boolean hielo = this.hielo.isChecked();
        Bebida mibeb = new Bebida(lista03.getSelectedItem().toString(), hielo);

        Intent int01 = new Intent(this, MainActivity2.class);
        int01.putExtra("CLIENTE", cliente.getText().toString());
        int01.putExtra("HAMBURGUESA", miham);
        int01.putExtra("BEBIDA", mibeb);
        int01.putExtra("NUMHAM", numHam.getText());
        int01.putExtra("NUMBEB", numBeb.getText());
        startActivity(int01);
    }
    else
    { noti01("ERROR NOMBRE CLIENTE VACIO O MUY CORTO");}


}



}